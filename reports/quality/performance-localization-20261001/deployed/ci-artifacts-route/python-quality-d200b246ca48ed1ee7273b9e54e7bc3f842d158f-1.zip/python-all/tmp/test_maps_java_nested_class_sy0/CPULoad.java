package oteldemo.problempattern;

class CPULoad {
    static class Logarithmizer {
        void run() {
            for (int i = 0; i < 10; i++) {
                Math.log(i + 1);
            }
        }
    }
}
