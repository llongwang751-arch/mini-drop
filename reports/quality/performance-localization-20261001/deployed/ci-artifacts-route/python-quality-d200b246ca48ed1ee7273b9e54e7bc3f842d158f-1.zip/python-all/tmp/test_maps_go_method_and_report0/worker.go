package demo

type Worker struct{}

func (w *Worker) HotLoop(ch chan int) {
    for value := range ch {
        go func() { _ = value }()
    }
}
