# PostgreSQL
Inspect lock waits and transaction duration.