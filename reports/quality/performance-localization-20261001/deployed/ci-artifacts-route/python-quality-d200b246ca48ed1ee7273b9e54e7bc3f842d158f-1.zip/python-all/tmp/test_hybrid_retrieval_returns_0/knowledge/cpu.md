# CPU 初筛

先看系统指标，不要直接归因。

## Python 热点

py-spy 能定位 GIL 和 Python 热点函数。