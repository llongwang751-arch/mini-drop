package main
func calculate(data []byte) []byte {
 return data
}
