#include <unistd.h>

int Worker::hot_loop(int count) {
    while (count-- > 0) {
        usleep(1000);
    }
    return count;
}
