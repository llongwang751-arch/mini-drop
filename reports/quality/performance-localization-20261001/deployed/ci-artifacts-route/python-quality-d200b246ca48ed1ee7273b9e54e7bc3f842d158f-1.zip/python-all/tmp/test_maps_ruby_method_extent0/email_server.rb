def send_email(message)
  validate(message)
  deliver(message)
end

def health
  true
end
