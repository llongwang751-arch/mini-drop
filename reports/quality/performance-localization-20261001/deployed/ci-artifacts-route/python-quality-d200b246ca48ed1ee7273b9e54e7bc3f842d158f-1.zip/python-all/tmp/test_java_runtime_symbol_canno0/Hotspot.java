class Hotspot {
    void run() {}
}
