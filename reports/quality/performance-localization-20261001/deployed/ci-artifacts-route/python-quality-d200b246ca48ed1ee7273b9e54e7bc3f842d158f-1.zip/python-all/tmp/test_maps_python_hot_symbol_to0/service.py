import time

class Worker:
    def hot_loop(self):
        for _ in range(3):
            time.sleep(0.01)
