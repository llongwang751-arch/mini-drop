def work(items)
  items.each do |item|
    process(item) if item.ready?
  end
end

def later
  wait
end
