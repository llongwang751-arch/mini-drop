class Hotspot {
    void run() {}
}
