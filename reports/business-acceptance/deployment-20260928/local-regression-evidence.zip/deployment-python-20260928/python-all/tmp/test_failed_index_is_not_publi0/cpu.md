# CPU
Python GIL hotspot sampling py-spy